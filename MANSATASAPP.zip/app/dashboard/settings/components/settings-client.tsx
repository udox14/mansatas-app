'use client'

import { useState, useEffect } from 'react'
import { useFormState, useFormStatus } from 'react-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { CalendarDays, Loader2, PlusCircle, CheckCircle2, AlertCircle, Trash2, Power } from 'lucide-react'
import { tambahTahunAjaran, setAktifTahunAjaran, hapusTahunAjaran } from '../actions'

type TAProps = { id: string, nama: string, semester: number, is_active: boolean }

const initialState = { error: null as string | null, success: null as string | null }

function SubmitBtn() {
  const { pending } = useFormStatus()
  return (
    <Button type="submit" disabled={pending} className="w-full bg-emerald-600 hover:bg-emerald-700 h-11 text-white rounded-xl shadow-sm">
      {pending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin"/> Menyimpan...</> : 'Simpan Tahun Ajaran'}
    </Button>
  )
}

export function SettingsClient({ taData }: { taData: TAProps[] }) {
  const [isAddOpen, setIsAddOpen] = useState(false)
  const [isPending, setIsPending] = useState(false)
  const [state, formAction] = useFormState(tambahTahunAjaran, initialState)

  useEffect(() => {
    if (state?.success) {
      const timer = setTimeout(() => setIsAddOpen(false), 1500)
      return () => clearTimeout(timer)
    }
  }, [state?.success])

  const handleSetAktif = async (id: string, nama: string, semester: number) => {
    if (!confirm(`TINDAKAN GLOBAL!\n\nAnda yakin ingin mengaktifkan ${nama} Semester ${semester}?\n\nSemua data Jurnal Guru, Kehadiran, dan Penugasan akan otomatis beralih ke periode ini.`)) return
    
    setIsPending(true)
    const res = await setAktifTahunAjaran(id)
    if (res?.error) alert(res.error)
    setIsPending(false)
  }

  const handleHapus = async (id: string, is_active: boolean) => {
    if (is_active) {
      alert('Tahun Ajaran ini sedang aktif dan tidak bisa dihapus!')
      return
    }
    if (!confirm('Yakin ingin menghapus periode ini?')) return
    
    setIsPending(true)
    const res = await hapusTahunAjaran(id, is_active)
    if (res?.error) alert(res.error)
    setIsPending(false)
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/60 shadow-sm p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 border-b border-slate-100 pb-6">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-100 p-2.5 rounded-xl text-emerald-700 shadow-inner">
              <CalendarDays className="h-6 w-6"/>
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">Manajemen Tahun Ajaran</h2>
              <p className="text-sm text-slate-500">Atur periode akademik yang sedang berjalan di madrasah.</p>
            </div>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 shadow-md transition-all">
                <PlusCircle className="h-4 w-4"/> Buat Periode Baru
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md rounded-3xl">
              <DialogHeader><DialogTitle>Tambah Tahun Ajaran Baru</DialogTitle></DialogHeader>
              <form action={formAction} className="space-y-5 py-2">
                {state?.error && <div className="p-3 text-sm text-rose-600 bg-rose-50 rounded-xl border border-rose-100 flex gap-2"><AlertCircle className="h-4 w-4 shrink-0"/> {state.error}</div>}
                {state?.success && <div className="p-3 text-sm text-emerald-700 bg-emerald-50 rounded-xl border border-emerald-100 flex gap-2"><CheckCircle2 className="h-4 w-4 shrink-0"/> {state.success}</div>}

                <div className="space-y-2">
                  <Label>Nama Tahun Ajaran</Label>
                  <Input name="nama" placeholder="Contoh: 2025/2026" required className="h-11 rounded-xl bg-slate-50 focus:bg-white focus:border-emerald-500" />
                </div>
                <div className="space-y-2">
                  <Label>Semester</Label>
                  <Select name="semester" defaultValue="1">
                    <SelectTrigger className="h-11 rounded-xl bg-slate-50"><SelectValue placeholder="Pilih Semester"/></SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="1">Ganjil (1)</SelectItem>
                      <SelectItem value="2">Genap (2)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="pt-2"><SubmitBtn /></div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* LIST TAHUN AJARAN */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {taData.length === 0 ? (
            <div className="col-span-full p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 text-slate-500">
              Belum ada data Tahun Ajaran. Silakan buat periode baru.
            </div>
          ) : (
            taData.map(ta => (
              <div 
                key={ta.id} 
                className={`p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
                  ta.is_active 
                    ? 'bg-emerald-50 border-emerald-300 shadow-md ring-2 ring-emerald-100 ring-offset-2' 
                    : 'bg-white border-slate-200 hover:border-emerald-200 hover:shadow-sm'
                }`}
              >
                {ta.is_active && (
                  <div className="absolute -right-6 -top-6 h-24 w-24 bg-emerald-500 opacity-10 rounded-full blur-xl"></div>
                )}

                <div className="flex justify-between items-start relative z-10">
                  <div>
                    <h3 className={`text-2xl font-black tracking-tight ${ta.is_active ? 'text-emerald-900' : 'text-slate-800'}`}>
                      {ta.nama}
                    </h3>
                    <p className={`font-semibold mt-1 ${ta.is_active ? 'text-emerald-700' : 'text-slate-500'}`}>
                      Semester {ta.semester === 1 ? 'Ganjil' : 'Genap'}
                    </p>
                  </div>
                  
                  {ta.is_active ? (
                    <span className="inline-flex items-center gap-1.5 bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-sm animate-pulse">
                      <CheckCircle2 className="h-3.5 w-3.5" /> AKTIF
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-500 px-3 py-1 rounded-full text-xs font-semibold">
                      Non-Aktif
                    </span>
                  )}
                </div>

                <div className="mt-6 flex items-center justify-end gap-2 border-t border-slate-100/50 pt-4">
                  {!ta.is_active && (
                    <>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleSetAktif(ta.id, ta.nama, ta.semester)}
                        disabled={isPending}
                        className="gap-2 rounded-lg text-emerald-700 border-emerald-200 hover:bg-emerald-100"
                      >
                        <Power className="h-3.5 w-3.5" /> Aktifkan
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleHapus(ta.id, ta.is_active)}
                        disabled={isPending}
                        className="h-9 w-9 rounded-lg text-rose-500 hover:bg-rose-50 hover:text-rose-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  )
}