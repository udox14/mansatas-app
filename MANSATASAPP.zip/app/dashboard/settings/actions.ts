'use server'

import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'

// --- 1. Tambah Tahun Ajaran Baru ---
export async function tambahTahunAjaran(prevState: any, formData: FormData) {
  const supabase = createClient()
  
  const nama = formData.get('nama') as string
  const semester = parseInt(formData.get('semester') as string)

  if (!nama || !semester) return { error: 'Nama dan Semester wajib diisi.', success: null }

  // Cek apakah sudah ada yang sama persis
  const { data: existing } = await supabase
    .from('tahun_ajaran')
    .select('id')
    .eq('nama', nama)
    .eq('semester', semester)
    .single()

  if (existing) return { error: 'Tahun Ajaran dan Semester tersebut sudah ada!', success: null }

  const { error } = await supabase.from('tahun_ajaran').insert({ nama, semester, is_active: false })
  
  if (error) return { error: error.message, success: null }

  revalidatePath('/dashboard/settings')
  return { error: null, success: 'Tahun Ajaran berhasil ditambahkan.' }
}

// --- 2. Set Tahun Ajaran Aktif ---
export async function setAktifTahunAjaran(id: string) {
  const supabase = createClient()

  // Langkah 1: Matikan semua tahun ajaran yang sedang aktif
  const { error: errorReset } = await supabase
    .from('tahun_ajaran')
    .update({ is_active: false })
    .eq('is_active', true)

  if (errorReset) return { error: 'Gagal mereset status tahun ajaran: ' + errorReset.message }

  // Langkah 2: Aktifkan tahun ajaran yang dipilih
  const { error: errorSet } = await supabase
    .from('tahun_ajaran')
    .update({ is_active: true })
    .eq('id', id)

  if (errorSet) return { error: 'Gagal mengaktifkan tahun ajaran: ' + errorSet.message }

  revalidatePath('/', 'layout') // Revalidate seluruh aplikasi karena ini setting global
  return { success: 'Tahun Ajaran berhasil diaktifkan! Seluruh sistem sekarang menggunakan periode ini.' }
}

// --- 3. Hapus Tahun Ajaran ---
export async function hapusTahunAjaran(id: string, isActive: boolean) {
  if (isActive) return { error: 'Tidak bisa menghapus Tahun Ajaran yang sedang aktif. Aktifkan tahun ajaran lain terlebih dahulu.' }

  const supabase = createClient()
  const { error } = await supabase.from('tahun_ajaran').delete().eq('id', id)
  
  if (error) return { error: 'Gagal menghapus: ' + error.message }
  
  revalidatePath('/dashboard/settings')
  return { success: 'Tahun Ajaran berhasil dihapus.' }
}