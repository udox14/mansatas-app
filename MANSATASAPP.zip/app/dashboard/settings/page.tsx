import { createClient } from '@/utils/supabase/server'
import { redirect } from 'next/navigation'
import { SettingsClient } from './components/settings-client'
import { Settings } from 'lucide-react'

export const metadata = { title: 'Pengaturan Global - MANSATAS App' }

export default async function SettingsPage() {
  const supabase = createClient()
  
  // Pastikan hanya Super Admin atau Admin TU yang bisa buka ini
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (!['super_admin', 'admin_tu'].includes(profile?.role || '')) {
    redirect('/dashboard') // Lempar ke dashboard jika bukan admin
  }

  // Ambil data Tahun Ajaran, urutkan dari yang terbaru
  const { data: taData } = await supabase
    .from('tahun_ajaran')
    .select('*')
    .order('nama', { ascending: false })
    .order('semester', { ascending: false })

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center gap-3">
        <div className="bg-slate-800 p-3 rounded-2xl text-white shadow-sm border border-slate-700">
          <Settings className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Pengaturan Aplikasi</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manajemen parameter utama dan konfigurasi sistem Madrasah.
          </p>
        </div>
      </div>

      <SettingsClient taData={taData || []} />
    </div>
  )
}