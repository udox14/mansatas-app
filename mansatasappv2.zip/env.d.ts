// Lokasi: env.d.ts
// Type declarations untuk Cloudflare Workers bindings
// Digunakan oleh getCloudflareContext() dari @opennextjs/cloudflare

interface CloudflareEnv {
  // D1 Database
  DB: D1Database

  // R2 Bucket
  R2: R2Bucket

  // KV Namespace (incremental cache Next.js)
  NEXT_INC_CACHE_KV: KVNamespace

  // Environment variables
  BETTER_AUTH_SECRET: string
  BETTER_AUTH_URL: string
  R2_PUBLIC_URL: string
}
