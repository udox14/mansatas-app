// Lokasi: utils/auth/index.ts
// PERBAIKAN: better-auth v1.x menggunakan 'better-auth/adapters/drizzle' untuk D1
// Import path 'better-auth/adapters/d1' sudah tidak ada di versi terbaru

import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { admin } from 'better-auth/plugins'
import { nextCookies } from 'better-auth/next-js'

// D1 di better-auth v1 menggunakan drizzleAdapter dengan dialect 'sqlite'
// Kita wrap D1Database ke dalam interface yang kompatibel dengan Drizzle SQLite
export function createAuth(db: D1Database) {
  return betterAuth({
    database: drizzleAdapter(db as any, {
      provider: 'sqlite',
    }),
    secret: process.env.BETTER_AUTH_SECRET!,
    baseURL: process.env.BETTER_AUTH_URL!,
    emailAndPassword: {
      enabled: true,
      requireEmailVerification: false,
    },
    session: {
      cookieCache: {
        enabled: true,
        maxAge: 60 * 60 * 24 * 7, // 7 hari
      },
    },
    user: {
      additionalFields: {
        role: {
          type: 'string',
          required: false,
          defaultValue: 'wali_murid',
          input: true,
        },
        nama_lengkap: {
          type: 'string',
          required: false,
          input: true,
        },
        avatar_url: {
          type: 'string',
          required: false,
          input: false,
        },
      },
    },
    plugins: [
      admin({
        adminRoles: ['kepsek', 'admin_tu', 'wakamad'],
      }),
      nextCookies(),
    ],
  })
}

export type Auth = ReturnType<typeof createAuth>
