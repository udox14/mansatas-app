// Lokasi: app/dashboard/akademik/analitik/page.tsx
import { Suspense } from 'react'
import { getCurrentUser } from '@/utils/auth/server'
import { getDB, parseJsonCol } from '@/utils/db'
import { getCloudflareContext } from '@opennextjs/cloudflare'
import { redirect } from 'next/navigation'
import { PengaturanPanel } from './components/pengaturan-panel'
import { AnalitikClient } from './components/analitik-client'
import { LineChart } from 'lucide-react'

export const metadata = { title: 'Analitik Kelulusan - MANSATAS App' }

async function AnalitikDataFetcher() {
  const { env } = await getCloudflareContext()
  const db = getDB(env.DB)

  const [pengaturan, mapelResult, siswaResult] = await Promise.all([
    db.prepare("SELECT * FROM pengaturan_akademik WHERE id = 'global'").first<any>(),
    db.prepare('SELECT id, nama_mapel FROM mata_pelajaran ORDER BY nama_mapel').all<any>(),
    db.prepare(`
      SELECT s.id, s.nisn, s.nama_lengkap, s.kelas_id,
        k.tingkat, k.kelompok, k.nomor_kelas,
        rn.nilai_smt1, rn.nilai_smt2, rn.nilai_smt3, rn.nilai_smt4, rn.nilai_smt5, rn.nilai_um
      FROM siswa s
      JOIN kelas k ON s.kelas_id = k.id
      LEFT JOIN rekap_nilai_akademik rn ON rn.siswa_id = s.id
      WHERE k.tingkat = 12 AND s.status = 'aktif'
      ORDER BY s.nama_lengkap
    `).all<any>()
  ])

  // Parse nilai JSON columns
  const dataSiswa = (siswaResult.results || []).map((s: any) => ({
    ...s,
    kelas: { tingkat: s.tingkat, kelompok: s.kelompok, nomor_kelas: s.nomor_kelas },
    rekap_nilai_akademik: s.nilai_smt1 ? [{
      nilai_smt1: parseJsonCol(s.nilai_smt1),
      nilai_smt2: parseJsonCol(s.nilai_smt2),
      nilai_smt3: parseJsonCol(s.nilai_smt3),
      nilai_smt4: parseJsonCol(s.nilai_smt4),
      nilai_smt5: parseJsonCol(s.nilai_smt5),
      nilai_um: parseJsonCol(s.nilai_um),
    }] : []
  }))

  return (
    <>
      <PengaturanPanel pengaturan={pengaturan} mapelList={mapelResult.results || []} />
      <AnalitikClient dataSiswa={dataSiswa} pengaturan={pengaturan} />
    </>
  )
}

export default async function AnalitikPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/login')

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <div className="flex items-center gap-3">
        <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-700 shadow-sm border border-emerald-200/50">
          <LineChart className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Analitik Kelulusan & SNBP</h1>
          <p className="text-sm text-slate-500 mt-1">Data Warehouse nilai dari RDM. Penghitungan otomatis kuota Eligible SNBP 40% & SPAN-PTKIN.</p>
        </div>
      </div>
      <Suspense fallback={
        <div className="bg-white/50 rounded-3xl p-12 border border-slate-200/60 shadow-sm flex flex-col items-center justify-center min-h-[500px]">
           <div className="bg-emerald-50 p-5 rounded-full mb-5 border border-emerald-100 relative">
             <div className="absolute inset-0 rounded-full border-4 border-emerald-200 border-t-emerald-600 animate-spin"></div>
             <LineChart className="h-8 w-8 text-emerald-600 animate-pulse" />
           </div>
           <h3 className="text-xl font-bold text-slate-800">Menarik Data Warehouse RDM...</h3>
        </div>
      }>
        <AnalitikDataFetcher />
      </Suspense>
    </div>
  )
}
